clc
clear
close all
load spiralexampledata
scatter(real(kspacelocations),imag(kspacelocations));
spiraldata = spiraldata(:);
[gdat] = gridkb(kspacelocations,spiraldata,dcf,256,1.5,3);
im = fftshift(fft2(fftshift(gdat)));

figure; 
imagesc(abs(im));colormap jet
axis square;
