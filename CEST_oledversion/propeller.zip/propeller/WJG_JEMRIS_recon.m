% reconstruct the JEMRIS K space
% created by Angus, wjtcw@hotmail.com
% 2018.9.9
% %% epi
% clc
% clear 
% close all
% addpath('LarsonLab')
% addpath('LarsonLab/shape_fcns')
% addpath('gridding')
% row=64;
% col=64;
% filename = 'signalsepi64.h5';
% fid = load_signal(filename);
% K_space_1 = fid(:,1);
% K_space_2 = fid(:,2);
% K_space_3 = fid(:,3);
% K_space = K_space_1+1i*K_space_2;
% K_space = reshape(K_space,[row,col]);
% figure;imagesc(log(abs(K_space)));colormap jet
% K_space(:,2:2:end) = flipud(K_space(:,2:2:end));
% figure;imagesc((abs(K_space)));colormap jet
% figure;imagesc(abs(fftshift(ifft2(ifftshift(K_space)))));colormap jet
% imshow(abs(fftshift(ifft2(ifftshift(K_space)))),[])
% filename = 'seqepi64.h5';
% hinfo = hdf5info(filename);
% RXP=h5read(filename,'/seqdiag/RXP');
% Iadc=find(RXP>=0);
% KX =h5read(filename,'/seqdiag/KX');
% KY =h5read(filename,'/seqdiag/KY');
% KX= KX(Iadc);
% KX = reshape(KX,[64,64]);
% KX(:,2:2:end) = flipud(KX(:,2:2:end));
% KX = KX(:);
% KY= KY(Iadc);
% scatter(KX(start:start+63),KY(start:start+63));hold on
% %calculate DCF
% [K,DCF]=DoCalcDCF(KX, KY);
% kspacelocations = KX+1i*KY;
% kspacelocations = kspacelocations/11;
% spiraldata = K_space(:);
% [gdat] = gridkb(kspacelocations,spiraldata,DCF,64,1.5,2);
% imagesc(abs(gdat));colormap jet
% im = fftshift(fft2(fftshift(gdat)));
% 
% figure; 
% imagesc(abs(im));colormap jet


%% propeller
%refer to jemris_propeller.doc
clc
clear 
close all
addpath('LarsonLab')
addpath('LarsonLab/shape_fcns')
addpath('gridding')
seg=2;
FOVx = 256;%unit mm
FOVy = 256;%mm
NL = 20;    %the number of phase collected in one blade;
NY = 64;   %the resolution of the phase direction
NB = 10;    % the number of blades
Kx_max = NY/2/FOVx*2*pi;    %rad/mm
Ky_max = Kx_max;
%k-space
filename = 'propeller_NL20_NY64_NB10signals_brain.h5';
hinfo = hdf5info(filename);
dset = hdf5read(hinfo.GroupHierarchy.Groups(1).Groups(1).Datasets(1));
K_space_1 = reshape(dset(1,:),[NY,NL*NB]);
K_space_2 = reshape(dset(2,:),[NY,NL*NB]);
K_space_3 = reshape(dset(3,:),[NY,NL*NB]);
K_space = K_space_1+1i*K_space_2;
K_space(:,2:2:end) = flipud(K_space(:,2:2:end));    %should be changed
K_space = K_space(:);
K_space = K_space(1+(seg-1)*NL*NY:(seg)*NL*NY);
% figure;imagesc(log(abs(K_space)));colormap jet
%location
filename = 'propeller_NL20_NY64_NB10seq_brain.h5';
hinfo = hdf5info(filename);
RXP=h5read(filename,'/seqdiag/RXP');
Iadc=find(RXP>=0);
KX =h5read(filename,'/seqdiag/KX');
KY =h5read(filename,'/seqdiag/KY');
KX= KX(Iadc);
KX = reshape(KX,[NY,NL*NB]);
KX(:,2:2:end) = flipud(KX(:,2:2:end));
KX = KX(:)/Kx_max*0.5;  %normalized
KY= KY(Iadc);
KY = reshape(KY,[NY,NL*NB]);
KY(:,2:2:end) = flipud(KY(:,2:2:end));
KY = KY(:)/Ky_max*0.5; %normalized
% scatter(KX(1:100),KY(1:100))
%calculate DCF
KX = KX(1+(seg-1)*NL*NY:(seg)*NL*NY);
KY = KY(1+(seg-1)*NL*NY:(seg)*NL*NY);
[K,DCF]=DoCalcDCF(KX, KY);

% % calculate Kaiser-Bessel Kernel
KernelSample = 10;
KernelWidth  = 4;
OverGrid = 1.2;
[Ker,KGrid] = DoCalcKBKernel(KernelSample, KernelWidth, OverGrid);
% % gridding according to given parameters
Kx=KX;
Ky=KY;
Sx = real(K_space);
Sy = imag(K_space);
GridSize = round(NY * OverGrid);
[Sx2,Sy2]= DoGridding(Kx,Ky,Sx,Sy,DCF,Ker,GridSize,KernelWidth/2);
gdat = fliplr(Sx2+1i*Sy2);
im = fftshift(fft2(fftshift(gdat)));
figure;imagesc(abs(im));colormap jet
figure; imagesc(abs(gdat));colormap jet
%%
% kspacelocations = K;
% spiraldata = K_space;
% [gdat] = gridkb(kspacelocations,spiraldata,DCF,NY,1.5,3);
% im = fftshift(fft2(fftshift(gdat)));
% figure;imagesc(abs(im));colormap jet
% figure; imagesc(abs(gdat));colormap jet













